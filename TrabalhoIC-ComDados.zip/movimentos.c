#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include "clientes.h"
#include "utils.h"
#include "contas.h"
#include "movimentos.h"

int idxMovimentos=-1;

void incluirMovimento(Movimento movimento) {
  
    idxMovimentos++;

    movimentos[idxMovimentos].idxConta=movimento.idxConta;
    movimentos[idxMovimentos].segundos=time(NULL);
    movimentos[idxMovimentos].valor=movimento.valor;
    movimentos[idxMovimentos].tipo=movimento.tipo;
    memcpy(movimentos[idxMovimentos].descricao, movimento.descricao, sizeof movimentos[idxMovimentos].descricao);
    
    contas[movimento.idxConta].saldo += (movimento.tipo == CREDITO) ? movimento.valor : (movimento.valor * -1);

}

int buscarPrimeiroMovimentoDaConta(int idxConta) {

    int laco;

    for (laco = 0; laco <= idxMovimentos; laco++) {

        if (idxConta == movimentos[laco].idxConta) {

            return laco;

        }

    }

    return -1;

}

void excluirMovimento(int idx) {

    if (idx >= 0 && idx <= idxMovimentos) {
        
        int laco;

        for (laco = idx;laco < idxMovimentos;laco++) {
            
            movimentos[laco].idxConta=movimentos[laco+1].idxConta;
            movimentos[laco].segundos=movimentos[laco+1].segundos;
            movimentos[laco].valor=movimentos[laco+1].valor;
            movimentos[laco].tipo=movimentos[laco+1].tipo;
            memcpy(movimentos[laco].descricao, movimentos[laco+1].descricao, sizeof movimentos[laco+1].descricao);

        }
        
        idxMovimentos--;
        
    }

}

void excluirMovimentosDaConta(int idxConta) {
    
    int alvo;

    while ((alvo = buscarPrimeiroMovimentoDaConta(idxConta)) >= 0) {

        excluirMovimento(alvo);
        
    }

}

void mostrarMovimento(Movimento movimento) {

  printf("Tipo : %s\n", (movimento.tipo == CREDITO) ? "CREDITO" : "DEBITO");
  printf("Valor  : %0.2f\n", movimento.valor);

  struct tm tm = *localtime(&movimento.segundos);
  printf("Data/Hora : %02d/%02d/%d %02d:%02d:%02d\n", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900, tm.tm_hour, tm.tm_min, tm.tm_sec);

  printf("Descricao : %s\n", movimento.descricao);

}

void saqueConta() {

    Conta conta;

    limparBuffer();
    printf("\nInsira a agencia : ");
    scanf("%d", &conta.agencia);

    limparBuffer();
    printf("Insira o numero da conta : ");
    scanf("%d", &conta.numeroDaConta);

    int alvo=localizarConta(conta);

    if (alvo < 0) {

        printf("\nConta nao foi encontrado!\n");
        return;

    } else {
        
        Movimento movimento;
        movimento.idxConta=alvo;
        movimento.tipo = DEBITO;

        limparBuffer();
        printf("Insira o valor a ser sacado : ");
        scanf("%f", &movimento.valor);

        if (contas[alvo].saldo - movimento.valor < 0) {

            printf("\nNao foi possivel realizar o saque, Saldo Insuficiente");

            return;

        } else {
            
            limparBuffer();
            printf("Descricao do saque : ");
            fgets(movimento.descricao, 100, stdin);

            incluirMovimento(movimento);
            printf("\nSaque Realizado!\n");

        }

    } 

}

void depositarConta() {
    
    Conta conta;

    limparBuffer();
    printf("\nInsira a agencia : ");
    scanf("%d", &conta.agencia);

    limparBuffer();
    printf("Insira o numero da conta : ");
    scanf("%d", &conta.numeroDaConta);

    int alvo=localizarConta(conta);

    if (alvo < 0) {

        printf("\nConta nao foi encontrado!\n");
        return;

    } else {
        
        Movimento movimento;
        movimento.idxConta=alvo;
        movimento.tipo = CREDITO;

        limparBuffer();
        printf("Insira o valor a ser depositado : ");
        scanf("%f", &movimento.valor);
        
        limparBuffer();
        printf("Descricao do deposito : ");
        fgets(movimento.descricao, 100, stdin);
        
        incluirMovimento(movimento);

        printf("\nDeposito Realizado!\n");

    }
}

void transferenciaConta() {

    Conta conta;
    
    limparBuffer();
    printf("\nInsira a agencia origem : ");
    scanf("%d", &conta.agencia);

    limparBuffer();
    printf("Insira o numero da conta origem : ");
    scanf("%d", &conta.numeroDaConta);

    int origem=localizarConta(conta);

    if (origem < 0) {

        printf("\nConta nao foi encontrado!\n");
        return;

    } else {
        
        Movimento movimento;

        mostrarConta(contas[origem]);

        limparBuffer();
        printf("\nInsira o valor a ser transferido : ");
        scanf("%f", &movimento.valor);

        if (contas[origem].saldo - movimento.valor < 0) {

            printf("\nNao foi possivel realizar a transferencia!\n");
            return;

        } else {
            
            limparBuffer();
            printf("\nInsira a agencia destino : ");
            scanf("%d", &conta.agencia);

            limparBuffer();
            printf("Insira o numero da conta destino : ");
            scanf("%d", &conta.numeroDaConta);

            int destino=localizarConta(conta);

            if (destino < 0 || destino == origem) {

                printf("\nConta nao foi encontrada!\n");
                return;

            } else {
                
                mostrarConta(contas[destino]);
                
                sprintf(movimento.descricao, "Transferencia para conta : {%d}-{%d}", contas[destino].agencia, contas[destino].numeroDaConta);
                movimento.tipo = DEBITO;
                movimento.idxConta = origem;
                incluirMovimento(movimento);
                
                sprintf(movimento.descricao, "Transferencia de conta : {%d}-{%d}", contas[origem].agencia, contas[origem].numeroDaConta);
                movimento.tipo = CREDITO;
                movimento.idxConta = destino;
                incluirMovimento(movimento);

                printf("\nTransferencia concluida!\n");

            }

        }

    }    
    
}

void dadosParaTeste_movimentos() {

    Movimento movimento;
    
    movimento.idxConta=3;
    movimento.valor=5000;
    movimento.tipo=CREDITO;
    sprintf(movimento.descricao, "Deposito inicial");
    incluirMovimento(movimento);

    movimentos[0].segundos -= (15 * 24 * 60 * 60);
    
    movimento.idxConta=3;
    movimento.valor=1750;
    movimento.tipo=DEBITO;
    sprintf(movimento.descricao, "Saque para halloween");
    incluirMovimento(movimento);

    movimento.idxConta=3;
    movimento.valor=1500;
    movimento.tipo=CREDITO;
    sprintf(movimento.descricao, "Deposito extra");
    incluirMovimento(movimento);
    
    movimento.idxConta=3;
    movimento.valor=1300;
    movimento.tipo=DEBITO;
    sprintf(movimento.descricao, "Transferencia para conta: {4000}-{5978}");
    incluirMovimento(movimento);

    movimento.idxConta=2;
    movimento.valor=1300;
    movimento.tipo=CREDITO;
    sprintf(movimento.descricao, "Transferencia de conta: {5050}-{6080}");
    incluirMovimento(movimento);

}