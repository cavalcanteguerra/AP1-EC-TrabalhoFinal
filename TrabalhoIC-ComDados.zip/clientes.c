#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include "clientes.h"
#include "contas.h"
#include "utils.h"

int idxClientes=-1;

//Parte dos Clientes

//Inclusao e organizacao do cliente

void incluirCliente (Cliente cliente) {
    
    if (idxClientes == (MAXCLIENTES-1)) {

        printf("\nImpossivel cadastrar mais clientes!\n");
        return;
        
    }

    int posicao = 0;
    
    for (int laco=0;laco<=idxClientes;laco++) {
        
        if (strcmp(cliente.nome, clientes[laco].nome) < 0) {
            
            break;
            
        }
        
        posicao++;
        
    }
    
    for (int laco=idxClientes;laco>=posicao;laco--) {
        
        clientes[laco+1].codigo=clientes[laco].codigo;
        memcpy(clientes[laco+1].nome, clientes[laco].nome, sizeof clientes[laco].nome);
        clientes[laco+1].cpfCnpj=clientes[laco].cpfCnpj;
        clientes[laco+1].telefone=clientes[laco].telefone;
        memcpy(clientes[laco+1].endereco, clientes[laco].endereco, sizeof clientes[laco].endereco);
        
    }
    
    clientes[posicao].codigo = cliente.codigo;
    memcpy(clientes[posicao].nome, cliente.nome, sizeof cliente.nome);
    clientes[posicao].cpfCnpj = cliente.cpfCnpj;
    clientes[posicao].telefone = cliente.telefone;
    memcpy(clientes[posicao].endereco, cliente.endereco, sizeof cliente.endereco);
    
    idxClientes++;
    
}

//Excluir cliente

void excluirCliente(int alvo) {
    
    excluirContasDoCliente(clientes[alvo].codigo);

    for (int laco=alvo;laco<idxClientes;laco++) {
        
        memcpy(clientes[laco].nome, clientes[laco+1].nome, sizeof clientes[laco+1].nome);
        clientes[laco].codigo=clientes[laco+1].codigo;
        clientes[laco].cpfCnpj=clientes[laco+1].cpfCnpj;
        clientes[laco].telefone=clientes[laco+1].telefone;
        memcpy(clientes[laco].endereco, clientes[laco+1].endereco, sizeof clientes[laco+1].endereco);
        
    }
    
    idxClientes--;
    
}

//Impressao na tela do cliente

void mostrarCliente (Cliente cliente) {
    
    printf("\n");
    
    printf("Nome : %s\n", cliente.nome);
    printf("Codigo : %d\n", cliente.codigo);
    printf("CPF/CNPJ : %ld\n", cliente.cpfCnpj);
    printf("Telefone : %ld\n", cliente.telefone);
    printf("Endereco : %s\n", cliente.endereco);
    
}

//Localizaçao de cliente

int localizarCliente (char tipoBusca, Cliente cliente) {
    
    int laco;
    
    tipoBusca=toupper(tipoBusca);
    
    for (laco=0;laco<=idxClientes;laco++) {
        
        if (tipoBusca=='C' && clientes[laco].codigo==cliente.codigo) {
            
            return laco;
            
        }
        
        if (tipoBusca=='P' && clientes[laco].cpfCnpj==cliente.cpfCnpj) {
            
            return laco;
            
        }
        
        if (tipoBusca=='N' && clientes[laco].nome==cliente.nome) {
            
            return laco;
            
        }
        
    }
    
    return -1;
    
}

//Cadastramento De Clientes

void criarCliente () {
    
    Cliente cliente;
    
    printf("\nCadastro de Cliente\n");
    
    limparBuffer();
    printf("Insira Código : ");
    scanf("%d", &cliente.codigo);
    
    if (localizarCliente('C', cliente)>=0) {
        
        printf("Cliente já cadastrado!\n");
        return;
        
    }
    
    
    limparBuffer();
    printf("Insira CPF/CNPJ : ");
    scanf("%ld", &cliente.cpfCnpj);
    
    if (localizarCliente('P', cliente)>=0) {
        
        printf("Cliente já cadastrado!\n");
        return;
        
    }
    
    limparBuffer();
    printf("Insira Nome : ");
    fgets(cliente.nome, 100, stdin);

    printf("Insira Endereco : ");
    fgets(cliente.endereco, 100,stdin);
    
    printf("Insira Telefone : ");
    scanf("%ld", &cliente.telefone);
    limparBuffer();
    
    incluirCliente(cliente);
    
    printf("\nCliente Cadastrado!\n\n");
    
}

//Listagem de cliente

void listarCliente () {
    
    if (idxClientes==-1) {
        
        printf("\nNenhum cliente cadastrado!\n");
        return;
        
    } else {
        
        printf("\nListagem dos clientes ja cadastrado :\n");
        
        int laco;
        
        for (laco=0;laco<=idxClientes;laco++) {
            
            mostrarCliente(clientes[laco]);
            
        }
        
    }
    
}

//Procurar Cliente

void procurarCliente () {
    
    char opcao;
    
    Cliente cliente;
    
    printf("\nProcurar cliente por : \n");
    printf("N - Nome\n");
    printf("C - Codigo\n");
    printf("P - CPF/CNPJ\n");
    
    scanf("%s", &opcao);
    
    switch (toupper(opcao)) {
        
        case 'N':
            limparBuffer();
            printf("\nInserir Nome : ");
            fgets(cliente.nome, 100, stdin);
            break;
       
        case 'C':
            limparBuffer();
            printf("\nInserir Codigo : ");
            scanf("%d", &cliente.codigo);
            break;
        
        case 'P':
            limparBuffer();
            printf("\nInserir CPF/CNPJ : ");
            scanf("%ld", &cliente.cpfCnpj);
            break;
        
        default :
            return;
        
    }
    
    int alvo=localizarCliente(opcao, cliente);
    
    if (alvo < 0) {
        
        printf("\nErro : Cliente nao encontrado\n");
        
    } else {
        
        mostrarCliente(clientes[alvo]);
        
    }
    
}

//Atualizar o Cadastro do Cliente

void atualizacaoDoCliente () {
    
    char opcao;
    
    Cliente cliente;
    
    printf("\nProcurar cliente por : \n");
    printf("C - Codigo\n");
    printf("P - CPF/CNPJ\n");
    
    limparBuffer();
    
    scanf("%c", &opcao);
    
    switch (toupper(opcao)) {
        
        case 'C':
            limparBuffer();
            printf("\nInsira o codigo: ");
            scanf("%d", &cliente.codigo);
            break;
        
        case 'P':
            limparBuffer();
            printf("\nInsira o CPF/CNPJ: ");
            scanf("%ld", &cliente.cpfCnpj);
            break;
        
        default:
            return;
        
    }
    
    int alvo=localizarCliente(opcao, cliente);
    
    if (alvo < 0) {
        
        printf("\nErro : Cliente nao encontrado\n");
        
    } else {
        
        mostrarCliente(clientes[alvo]);
        
        printf("\nDeseja atualizar esta conta : \n");
        printf("S - Sim\n");
        printf("N - Nao\n");
        
        char confirma='x';
        
        while (confirma != 'S' && confirma != 'N') {
            
            limparBuffer();
            
            scanf("%c", &confirma);
            
            confirma=toupper(confirma);
            
        }
        
        if (confirma == 'S') {
            
            limparBuffer();
            printf("Insira Código : ");
            scanf("%d", &cliente.codigo);
            
            if (localizarCliente('C', cliente)>=0 && localizarCliente('C', cliente) != alvo) {
                
                printf("Cliente já cadastrado!\n");
                return;
                
            }
            
            
            limparBuffer();
            printf("Insira CPF/CNPJ : ");
            scanf("%ld", &cliente.cpfCnpj);
            
            if (localizarCliente('P', cliente)>=0 && localizarCliente('P', cliente) != alvo) {
                
                printf("Cliente já cadastrado!\n");
                return;
                
            }
            
            limparBuffer();
            printf("Insira Nome : ");
            fgets(cliente.nome, 100, stdin);
            
            limparBuffer();
            printf("Insira Endereco : ");
            fgets(cliente.endereco, 100,stdin);
            
            limparBuffer();
            printf("Insira Telefone : ");
            scanf("%ld", &cliente.telefone);
            
            excluirCliente(alvo);
            
            incluirCliente(cliente);
            
            printf("\nCliente alterado!\n\n");
            
        }
        
    }
    
}

//Excluir o Cliente 

void exclusaoCliente () {
    
    char opcao;
    
    Cliente cliente;
    
    printf("\nProcurar cliente por : \n");
    printf("C - Codigo\n");
    printf("P - CPF/CNPJ\n");
    
    limparBuffer();
    
    scanf("%c", &opcao);
    
    switch (toupper(opcao)) {
        
        case 'C':
            limparBuffer();
            printf("\nInsira o codigo: ");
            scanf("%d", &cliente.codigo);
            break;
        
        case 'P':
            limparBuffer();
            printf("\nInsira o CPF/CNPJ: ");
            scanf("%ld", &cliente.cpfCnpj);
            break;
        
        default:
            return;
    }
    
    int alvo=localizarCliente(opcao, cliente);
    
    if (alvo < 0) {
        
        printf("\nErro : Cliente nao encontrado\n");
        
    } else {
        
        mostrarCliente(clientes[alvo]);
        
        printf("\nDeseja apagar esta conta : \n");
        printf("S - Sim\n");
        printf("N - Nao\n");
        
        char confirma='x';
        
        while (confirma != 'S' && confirma != 'N') {
            
            limparBuffer();
            
            scanf("%c", &confirma);
            
            confirma=toupper(confirma);
            
        }
        
        if (confirma == 'S') {
            
            excluirCliente(alvo);
            
            printf("\nCliente excluido!\n");
            
        }
        
    }
    
}

//Menu De Gerenciar Cliente

void gerenciarCliente () {
    
    char opcao;
    
    while (1==1) {
        
        printf("\n============ Gerenciar Clientes ============\n");
        printf("Digite um comando para prosseguir:\n");
        printf("C - Cadastrar um cliente\n");
        printf("L - Listar todos os clientes cadastrados\n");
        printf("B - Buscar cliente já cadastrado\n");
        printf("A - Atualizar um cliente já cadastrado\n");
        printf("E - Excluir um cliente cadastrado\n");
        printf("S - Sair\n");
        
        limparBuffer();
        
        scanf("%c", &opcao);
        
        switch (toupper(opcao)) {
            
            case 'S':
                return;
                
            case 'C':
                criarCliente();
                break;
                
            case 'L':
                listarCliente();
                break;
            
            case 'B':
                procurarCliente();
                break;
            
            case 'E':
                exclusaoCliente();
                break;
            
            case 'A':
                atualizacaoDoCliente();
                break;
            
        }
        
    }
    
}

//dados para teste

void dadosParaTeste_clientes() {
    
    Cliente cliente;
    
    cliente.codigo=4;
    memcpy(cliente.nome, "Geralda Guerra", 100);
    cliente.cpfCnpj=41014324149;
    cliente.telefone=999186080;
    memcpy(cliente.endereco, "Av. Dr. Jose Hermano", 100);
    incluirCliente(cliente);
    
    cliente.codigo=3;
    memcpy(cliente.nome, "Eduardo Filho", 100);
    cliente.cpfCnpj=72981168126;
    cliente.telefone=999186080;
    memcpy(cliente.endereco, "Av. Dr. Jose Hermano", 100);
    incluirCliente(cliente);
    
    cliente.codigo=1;
    memcpy(cliente.nome, "Eduardo Guerra", 100);
    cliente.cpfCnpj=54759447172;
    cliente.telefone=999786080;
    memcpy(cliente.endereco, "Av. Dr. Jose Hermano", 100);
    incluirCliente(cliente);
    
    cliente.codigo=2;
    memcpy(cliente.nome, "Antares Informatica", 100);
    cliente.cpfCnpj=37597440000188;
    cliente.telefone=35457113;
    memcpy(cliente.endereco, "Av. Dr. Jose Hermano", 100);
    incluirCliente(cliente);
    
}

