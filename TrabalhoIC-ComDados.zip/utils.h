#ifndef UTILS
#define UTILS

void limparBuffer();

#endif