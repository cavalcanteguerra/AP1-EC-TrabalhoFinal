#ifndef CLIENTES
#define CLIENTES
#define MAXCLIENTES 100

typedef struct {
    
    int codigo;
    char nome[100];
    long int cpfCnpj;
    long int telefone;
    char endereco[100];
    
} Cliente;

Cliente clientes[MAXCLIENTES];

int idxClientes;

void dadosParaTeste_clientes();

void incluirCliente (Cliente);

void excluirCliente(int);

void mostrarCliente (Cliente);

int localizarCliente (char, Cliente);

void criarCliente ();

void listarCliente ();

void procurarCliente ();

void atualizacaoDoCliente ();

void exclusaoCliente ();

void gerenciarCliente();

#endif