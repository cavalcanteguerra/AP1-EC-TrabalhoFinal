#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include "clientes.h"
#include "utils.h"
#include "contas.h"
#include "movimentos.h"

int idxContas=-1;

void mostrarConta(Conta conta) {

    printf("\n");
    
    printf("Codigo do cliente : %d\n", conta.codigoCliente);
    printf("Agencia : %d\n", conta.agencia);
    printf("Numero da conta : %d\n", conta.numeroDaConta);
    printf("Saldo : %0.2f\n", conta.saldo);

}

void incluirConta (Conta conta) {
    
    idxContas++;

    contas[idxContas].codigoCliente=conta.codigoCliente;
    contas[idxContas].agencia=conta.agencia;
    contas[idxContas].numeroDaConta=conta.numeroDaConta;
    contas[idxContas].saldo=0;
    
}

int buscarPrimeiraContaDoCliente (int codigoCliente) {

    int laco;

    for (laco = 0; laco <= idxContas; laco++) {

        if (codigoCliente == contas[laco].codigoCliente) {

            return laco;

        }

    }

    return -1;

}

void excluirConta(int idx) {
    
    if (idx >= 0 && idx <= idxContas) {

        excluirMovimentosDaConta(idx);

        int laco;

        for (laco = idx; laco < idxContas; laco++) {

            contas[laco].codigoCliente=contas[laco+1].codigoCliente;
            contas[laco].agencia=contas[laco+1].agencia;
            contas[laco].numeroDaConta=contas[laco+1].numeroDaConta;
            contas[laco].saldo=contas[laco+1].saldo;

        }

        for (laco = 0; laco <= idxMovimentos; laco++) {

            if (movimentos[laco].idxConta >= idx) {

                movimentos[laco].idxConta--;
                
            }

        }

        idxContas--;

    }
    
}

void excluirContasDoCliente (int codigoCliente) {

    int alvo;

    while ((alvo = buscarPrimeiraContaDoCliente(codigoCliente)) >= 0) {

        excluirConta(alvo);
        
    }

}

int localizarConta(Conta conta) {

    int laco;

    for (laco=0;laco<=idxContas;laco++) {

        if (conta.agencia == contas[laco].agencia && conta.numeroDaConta == contas[laco].numeroDaConta) {

            return laco;
            
        }
        
    }
    
    return -1;

}

void listarContasCliente(Cliente cliente) {

    int laco;

    printf("\nContas de %s :\n", cliente.nome);
    
    for (laco=0;laco<=idxContas;laco++) {

        if (contas[laco].codigoCliente == cliente.codigo){

            mostrarConta(contas[laco]);

        }


    }

    
    
}

void listarTodasContas() {

    int laco;

    for (laco=0;laco<=idxClientes;laco++) {

        listarContasCliente(clientes[laco]);

    }
    
}

void listarContasPorCliente() {
    
    char opcao;
    
    Cliente cliente;

    printf("\nBuscar Cliente por : \n");
    printf("C - Codigo\n");
    printf("P - CPF/CNPJ\n");

    limparBuffer();
    
    scanf("%c", &opcao);
    
    switch (toupper(opcao)) {
       
        case 'C':
            limparBuffer();
            printf("\nInserir Codigo : ");
            scanf("%d", &cliente.codigo);
            break;
        
        case 'P':
            limparBuffer();
            printf("\nInserir CPF/CNPJ : ");
            scanf("%ld", &cliente.cpfCnpj);
            break;
        
        default :
            return;
        
    }
    
    int alvo=localizarCliente(opcao, cliente);
    
    if (alvo < 0) {
        
        printf("\nErro : Cliente nao encontrado\n");
        
    } else {

        listarContasCliente(clientes[alvo]);  

    }

}

void criarConta () {
    
    char opcao;
    
    Cliente cliente;

    printf("\nCriar conta por : \n");
    printf("C - Codigo\n");
    printf("P - CPF/CNPJ\n");

    limparBuffer();
    
    scanf("%c", &opcao);
    
    switch (toupper(opcao)) {
       
        case 'C':
            limparBuffer();
            printf("\nInserir Codigo : ");
            scanf("%d", &cliente.codigo);
            break;
        
        case 'P':
            limparBuffer();
            printf("\nInserir CPF/CNPJ : ");
            scanf("%ld", &cliente.cpfCnpj);
            break;
        
        default :
            return;
        
    }
    
    int alvo=localizarCliente(opcao, cliente);
    
    Conta conta;

    if (alvo < 0) {
        
        printf("\nErro : Cliente nao encontrado\n");
        
    } else {

        conta.codigoCliente = clientes[alvo].codigo;

        limparBuffer();
        printf("Insira a agencia : ");
        scanf("%d", &conta.agencia);

        limparBuffer();
        printf("Insira o numero da conta : ");
        scanf("%d", &conta.numeroDaConta);
        
        if (localizarConta(conta) >= 0) {

            printf("Conta já cadastrada");
            return;
            
        }

        incluirConta(conta);

        printf("\nConta Registrada!\n");       

    }

}

void exibirExtrato() {

    Conta conta;

    limparBuffer();
    printf("\nInsira a agencia : ");
    scanf("%d", &conta.agencia);

    limparBuffer();
    printf("Insira o numero da conta : ");
    scanf("%d", &conta.numeroDaConta);

    int alvo=localizarConta(conta);

    if (alvo < 0) {

        printf("\nConta nao foi encontrado!\n");
        return;

    } else {
      
      printf("\n");
    
      printf("Codigo do cliente : %d\n", contas[alvo].codigoCliente);
      printf("Agencia : %d\n", contas[alvo].agencia);
      printf("Numero da conta : %d\n", contas[alvo].numeroDaConta);
      printf("Saldo : %0.2f\n", contas[alvo].saldo);
      
      int qtdeDias,qtdeSegundos,laco;
      limparBuffer();
      printf("Quantidade de dias que deseja no extrato : ");
      scanf("%d", &qtdeDias);

      qtdeSegundos = qtdeDias * 24 * 60 * 60;
      time_t hoje = time(NULL);
    
      for (laco=0;laco<=idxMovimentos;laco++) {

        if (movimentos[laco].idxConta == alvo && movimentos[laco].segundos >= (hoje - qtdeSegundos)) {
            
            printf("\n");
            mostrarMovimento(movimentos[laco]);
          
        }
      }

    }
}

void gerenciarConta () {
    
    char opcao;
    
    while (1==1) {
        
        printf("\n============= Gerenciar Contas =============\n");
        printf("Digite um comando para prosseguir:\n");
        printf("R - Listagem de todos as contas cadastradas\n");
        printf("C - Cadastrar uma conta para um cliente\n");
        printf("L - Listar todas as contas de um cliente\n");
        printf("W - Realizar um saque em uma conta\n");
        printf("D - Realizar um depósito em uma conta\n");
        printf("T - Realizar transfêrencia entre contas\n");
        printf("E - Exibir extrato de uma conta\n");
        printf("S - Sair\n");
        
        limparBuffer();
        
        scanf("%c", &opcao);
        
        switch (toupper(opcao)) {
            
            case 'S':
                return;
            
            case 'C':
                criarConta();
                break;

            case 'R':
                listarTodasContas();
                break;
            
            case 'L':
                listarContasPorCliente();
                break;

            case 'D':
                depositarConta();
                break;

            case 'W':
                saqueConta();
                break;

            case 'T':
                transferenciaConta();
                break;

            case 'E':
                exibirExtrato();
            
            
        }
        
    }

}

void dadosParaTeste_contas() {
    
    Conta conta;
    
    conta.codigoCliente=2;
    conta.agencia=3485;
    conta.numeroDaConta=60333;
    incluirConta(conta);
    
    conta.codigoCliente=3;
    conta.agencia=3121;
    conta.numeroDaConta=66730;
    incluirConta(conta);

    conta.codigoCliente=1;
    conta.agencia=4000;
    conta.numeroDaConta=5978;
    incluirConta(conta);

    conta.codigoCliente=1;
    conta.agencia=5050;
    conta.numeroDaConta=6080;
    incluirConta(conta);
    
}