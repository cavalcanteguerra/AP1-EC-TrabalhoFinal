#ifndef CONTAS
#define CONTAS

typedef struct {
    
    int codigoCliente;
    int agencia;
    int numeroDaConta;
    float saldo;

} Conta;

Conta contas[200];

int idxContas;

void mostrarConta(Conta);

void gerenciarConta();

void criarConta();

int buscarPrimeiraContaDoCliente(int);

void excluirConta(int);

void excluirContasDoCliente(int);

void mostrarConta();

int localizarConta(Conta);

void incluirConta(Conta); 

void listarContasCliente(Cliente);

void listarTodasContas();

void listarContasPorCliente();

void exibirExtrato();

void dadosParaTeste_contas();

#endif