#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include "clientes.h"
#include "utils.h"
#include "contas.h"
#include "movimentos.h"

int main(void) {

  dadosParaTeste_clientes();
  dadosParaTeste_contas();
  dadosParaTeste_movimentos();
    
    char opcao;
    
    while (1==1) {
        
        printf("\n=============== Bem Vindo! ===============\n");
        printf("Digite um comando para prosseguir:\n");
        printf("C - Gerenciar clientes\n");
        printf("T - Gerenciar contas\n");
        printf("S - Sair\n");
        
        limparBuffer();

        opcao=getchar();
        
        switch (toupper(opcao)) {
            
            case 'C':
                gerenciarCliente();
                break;
            
            case 'T':
                gerenciarConta();
                break;
            
            case 'S':
                exit(0);
                break;
            
        } 
        
    }
    
}