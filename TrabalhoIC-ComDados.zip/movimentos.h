#ifndef MOVIMENTOS
#define MOVIMENTOS

enum TipoMovimento {
  CREDITO, 
  DEBITO
};

typedef struct {
  
  int idxConta;
  time_t segundos;
  float valor;
  enum TipoMovimento tipo;
  char descricao[100];

} Movimento;

Movimento movimentos[1000];

int idxMovimentos;

void incluirMovimento(Movimento);

int buscarPrimeiroMovimentoDaConta(int);

void excluirMovimento(int);

void excluirMovimentosDaConta(int);

void mostrarMovimento(Movimento);

void depositarConta();

void saqueConta();

void transferenciaConta();

void dadosParaTeste_movimentos();

#endif